.. {{cookiecutter.project_name}} documentation master file, created by
   sphinx-quickstart on Wed May  5 09:31:12 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to {{cookiecutter.project_name}}'s documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

-----
views
-----



..  toctree::
    :maxdepth: 2

    modules/views

------
models
------

..  toctree::
    :maxdepth: 2

    modules/models


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
